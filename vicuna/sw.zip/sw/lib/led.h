#ifndef LED_H
#define LED_H

#include <stdint.h>

void define_led_value(int led);

int get_led_value();

#endif