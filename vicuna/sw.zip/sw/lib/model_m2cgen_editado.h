#ifndef MODEL_M2CGEN_EDITADO_H
#define MODEL_M2CGEN_EDITADO_H

#include <stdint.h>

int16_t argmax(int16_t *x, int16_t size);

int16_t score(int16_t * input);

#endif