#ifndef RUNTIME_H
#define RUNTIME_H

#include <stdint.h>
uint64_t get_mcycle();
uint64_t get_minstret();
#endif

